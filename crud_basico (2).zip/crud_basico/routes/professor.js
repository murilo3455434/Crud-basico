const express = require('express');
const router = express.Router();
const { Professor } = require('../models');

router.get("/", async (req, res) => {
    const professor = await Professor.findAll();
    res.render("base", {
        title: "Listar professor",
        view: "professor/show",
        professor,
    });
});

router.get("/add", (req, res) => {
    res.render("base", {
        title: "Adicionar professor",
        view: "professor/add",
    });
});

router.post("/add", async(req, res) =>{
    await Professor.create({
        nome: req.body.nome,
        matricula: req.body.matricula
    });
    res.redirect("/professor");
});

router.get("/edit/:id", async (req, res) => {
    const professor = await Professor.findByPk(req.params.id);
    res.render("base", {
        title: "Editar professor",
        view: "professor/edit",
        professor,
    });
});


router.post('/edit/:id', async (req, res) => {
    await Professor.update(
        {
            nome: req.body.nome,
            matricula: req.body.matricula,
        },
        {
            where: { id: req.params.id } 
        }
    );
    res.redirect('/professor');
});


router.post("/delete/:id", async (req, res) => {
    await Professor.destroy({ where: { id: req.params.id } });
    res.redirect("/professor");
});

module.exports = router;
