const express = require('express');
const router = express.Router();
const { Aluno } = require('../models');


router.get("/", async (req, res) => {
    const aluno = await Aluno.findAll();
    res.render("base", {
        title: "Listar Alunos",
        view: "aluno/show",
        aluno,
    });
});

router.get("/add", async (req, res) => {
    res.render("base", {
        title: "Adicionar Aluno",
        view: "aluno/add",
    });
});


router.post("/add", async (req, res) => {
    await Aluno.create({ nome: req.body.nome, rm: req.body.rm });
    res.redirect("/aluno");
});

router.get("/edit/:id", async (req, res) => {
    const aluno = await Aluno.findByPk(req.params.id);
    res.render("base", {
        title: "Editar Aluno",
        view: "aluno/edit",
        aluno,
    });
});

router.post("/edit/:id", async (req, res) => {
    console.log("ID recebido:", req.params.id); 
    await Aluno.update(
        {
            nome: req.body.nome,
            rm: req.body.rm,
        },
        {
            where: { id: req.params.id }
        }
    );
    res.redirect("/aluno");
});

router.post("/delete/:id", async (req, res) => {
    await Aluno.destroy({ where: { id: req.params.id } });
    res.redirect("/aluno");
});

module.exports = router;
